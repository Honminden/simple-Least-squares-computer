public class LeastSquares
{
    public static void main(String[] args)
    {
        //define lists of x and y
        double[] x = {2.00,4.01,6.22,8.20,9.75,12.00,13.99,15.92,18.00,20.01};
        double[] y = {0.74,1.52,2.33,3.08,3.66,4.49,5.24,5.98,6.76,7.50};

        //use n to imitate a math writing style
        int n = x.length;

        //get ∑xi, ∑yi,∑xi²,∑yi²,∑xiyi
        double sumX = 0;
        for(int i = 0;i < n;i++)
        {
            sumX += x[i];
        }

        double sumY = 0;
        for(double add:y)
        {
            sumY += add;
        }

        double sumSquareX = 0;
        for(int i = 0;i < n;i++)
        {
            sumSquareX += Math.pow(x[i],2);
        }

        double sumSquareY = 0;
        for(double add:y)
        {
            sumSquareY += Math.pow(add,2);
        }

        double sumXY = 0;
        for(int i = 0;i < n;i++)
        {
            sumXY += x[i] * y[i];
        }

        //get lxx,lyy,lxy
        double lxx = sumSquareX - Math.pow(sumX,2) / n;

        double lyy = sumSquareY - Math.pow(sumY,2) / n;

        double lxy = sumXY - sumX * sumY / n;

        //solve r,k,b
        double r = lxy / Math.sqrt(lxx * lyy);

        double k = lxy / lxx;

        double b = (sumY - k * sumX) / n;

        //solve ∑vi²,Sy,Sk,Sb
        double sumSquareV = 0;
        for(int i = 0;i < n;i++)
        {
            sumSquareV += Math.pow(y[i] - k * x[i] - b,2);
        }

        double sy = Math.sqrt(sumSquareV / (n - 2));

        double sk = sy / Math.sqrt(sumSquareX - Math.pow(sumX,2) / n);

        double sb = sk * Math.sqrt(sumSquareX / n);

        //print the results to console

        //print xi
        System.out.print("       x: ");
        for(int i = 0;i < n;i++)
        {
            System.out.printf("%10.2f",x[i]);//is %10.2f because the precision is 0.01
        }
        System.out.println();

        //print yi
        System.out.print("       y: ");
        for(int i = 0;i < n;i++)
        {
            System.out.printf("%10.2f",y[i]);//is %10.2f because the precision is 0.01,too
        }
        System.out.println();

        //print n,∑xi, ∑yi,∑xi²,∑yi²,∑xiyi,lxx,lyy,lxy,r,k,b,∑vi²,Sy,Sk,Sb
        System.out.print("       n: " + n + "\n");
        System.out.print("     ∑xi: " + sumX + "\n");
        System.out.print("     ∑yi: " + sumY + "\n");
        System.out.print("    ∑xi²: " + sumSquareX + "\n");
        System.out.print("    ∑yi²: " + sumSquareY + "\n");
        System.out.print("   ∑xiyi: " + sumXY + "\n");
        System.out.print("     lxx: " + lxx + "\n");
        System.out.print("     lyy: " + lyy + "\n");
        System.out.print("     lxy: " + lxy + "\n");
        System.out.print("       r: " + r + "\n");
        System.out.print("       k: " + k + "\n");
        System.out.print("       b: " + b + "\n");
        System.out.print("    ∑vi²: " + sumSquareV + "\n");
        System.out.print("      Sy: " + sy + "\n");
        System.out.print("      Sk: " + sk + "\n");
        System.out.print("      Sb: " + sb + "\n");
    }

}
